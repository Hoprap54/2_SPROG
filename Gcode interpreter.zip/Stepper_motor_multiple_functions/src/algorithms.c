#include "algorithms.h"

double giveMaxTerm(double x, double y)
{
    if (x > y)
        return x;
    else
        return y;
}
